<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StudentCoursePayHistory extends Model
{
    protected $table = 'student_course_pay_history';
}
