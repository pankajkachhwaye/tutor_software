<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StudentDailyPayHistory extends Model
{
    protected $table = 'student_daily_pay_history';
}
