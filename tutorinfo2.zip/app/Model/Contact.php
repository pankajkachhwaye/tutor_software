<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $table = 'contact';

    public function dailyWorkReport(){
        return $this->hasMany('App\Model\DailyWorkReport','contact_id');
    }

    public function groupDailyWorkReport(){
        return $this->hasMany('App\Model\DailyWorkReport','contact_id')->groupBy('student_name');
    }

    public function courses(){
        return $this->hasMany('App\Model\Course','contact_id');
    }
}
