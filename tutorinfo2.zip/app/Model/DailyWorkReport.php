<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DailyWorkReport extends Model
{
   protected $table = 'daily_work';


}
