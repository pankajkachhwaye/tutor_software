<?php

namespace App\Http\Controllers\Admin;

use App\Model\DailyWorkReport;

use App\Model\Course;
use App\Model\Contact;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DailyWorkController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add($id){
        $page = 'contact';
        return view('tutor.daily-work.dailyworkadd',compact('page','id'));
    }

    public function createDailyWork(Request $request){



        $temp_data = $request->all();
        $remaining = intval($temp_data['price']) - intval($temp_data['paid']);
        $tutor_name = $temp_data['tutor_name'];
        $tutor_price = $temp_data['tutor_price'];
        unset($temp_data['_token']);
        unset($temp_data['counter']);
        $temp_data['remaining'] = $remaining;
        $temp_data['tutor_name'] = json_encode($tutor_name);
        $temp_data['tutor_price'] = json_encode($tutor_price);
        $temp_data['created_at'] = Carbon::now();
        $insert = DailyWorkReport::insert($temp_data);



        if($insert){
            return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
        }
    }

    public function show()
    {

       $contactData= Contact::orderBy('created_at','asc')->get();
//       dd($contactData);
//       $data= DailyWorkReport::where('contact_id',$id)->get();
//       $courseData= Course::where('contact_id',$id)->get();
       //DailyWorkReport::all();
        //dd($id);

        return view('tutor.daily-work.student_details',compact('contactData'));

    }

    public function createCourse(Request $request )
    {

        //         dd($request->all());
        $temp_data = $request->all();
        $tutor_name = $temp_data['tutor_name'];
        $tutor_price = $temp_data['tutor_price'];
        unset($temp_data['_token']);
        unset($temp_data['counter']);
        $remaining = intval($temp_data['price']) - intval($temp_data['paid']);
        $temp_data['remaining'] = $remaining;
        $temp_data['tutor_name'] = json_encode($tutor_name);
        $temp_data['tutor_price'] = json_encode($tutor_price);
        $temp_data['created_at'] = Carbon::now();
        $insert = Course::insert($temp_data);

        if($insert){
            return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
        }
    }


    public function payDailyWork(Request $request){

        $data = DailyWorkReport::where('student_name',$request->student_name)->orderBy('created_at','asc')->get();
        $ammount = $request->amount;
        foreach ($data as $key => $value){
            if($value->remaining > $ammount){
                $minus_amt = intval($value->remaining) - intval($ammount);
                $value->remaining = $minus_amt;
                $value->save();
                    break;
            }
            else{
                $ammount = intval($ammount) - intval($value->remaining);
                $value->remaining = 0;
                $value->save();
            }
         }
        return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
    }

    public function payCourse(Request $request){

        $data = Course::where('student_name',$request->student_name)->orderBy('created_at','asc')->get();
        $ammount = $request->amount;
        foreach ($data as $key => $value){
            if($value->remaining > $ammount){
                $minus_amt = intval($value->remaining) - intval($ammount);
                $value->remaining = $minus_amt;
                $value->save();
                break;
            }
            else{
                $ammount = intval($ammount) - intval($value->remaining);
                $value->remaining = 0;
                $value->save();
            }
        }
        return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
    }

    public function addCourse($id)
    {

        $page = 'contact';
        return view('tutor.daily-work.dailycourse',compact('page','id'));
    }



}
