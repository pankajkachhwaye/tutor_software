<?php

namespace App\Http\Controllers\Admin;

use App\Model\Contact;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        $page = 'dashboard';
        return view('tutor.admin.dashboard', compact('page'));
    }

    public function contacts(){
        $contacts = Contact::orderBy('created_at','desc')->get();
        $page = 'contact';
//        dd($contacts);
        return view('tutor.contact.showcontact', compact('page','contacts'));
    }

    public function addNewContact(Request $request){
        $temp_data = $request->all();
        unset($temp_data['_token']);
        $temp_data['created_at'] = Carbon::now();
        $insert = Contact::insert($temp_data);

        if($insert){
            return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
        }
    }

    public function deleteContact($id){
        $item = Contact::find($id);
        $item->delete();
        return redirect('daily-work-entry/show')->with('returnStatus', true)->with('status', 101)->with('message', 'Work Report Added successfully');
    }
}
