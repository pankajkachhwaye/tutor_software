@extends('app')

@section('main-content')

<section class="content">
        <div class="loading-custom preloader pl-size-xs">
            <div class="spinner-layer pl-red-grey">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>

    <div class="container-fluid">
        <div class="block-header">
            <h2>DASHBOARD</h2>
        </div>

      


    </div>




</section>

    @endsection
